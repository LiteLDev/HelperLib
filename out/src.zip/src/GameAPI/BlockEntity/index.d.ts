/* eslint-disable @typescript-eslint/triple-slash-reference */

/// <reference path="BlockEntity.d.ts" />
