/* eslint-disable @typescript-eslint/triple-slash-reference */

/// <reference path="Basic/index.d.ts" />
/// <reference path="Block/index.d.ts" />
/// <reference path="BlockEntity/index.d.ts" />
/// <reference path="Container.d.ts" />
/// <reference path="Device.d.ts" />
/// <reference path="Entity.d.ts" />
/// <reference path="GameUtils.d.ts" />
/// <reference path="Player.d.ts" />
/// <reference path="Item.d.ts" />
/// <reference path="Packet.d.ts" />
/// <reference path="ScoreBoard.d.ts" />
/// <reference path="Server.d.ts" />
