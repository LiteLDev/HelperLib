/* eslint-disable @typescript-eslint/triple-slash-reference */

/// <reference path="./Command.d.ts" />
/// <reference path="./CommandOrigin.d.ts" />
/// <reference path="./CommandOutput.d.ts" />
/// <reference path="./mc.d.ts" />
/// <reference path="./types.d.ts" />
