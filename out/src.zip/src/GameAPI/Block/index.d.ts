/* eslint-disable @typescript-eslint/triple-slash-reference */

/// <reference path="Block.d.ts" />
/// <reference path="mc.d.ts" />
