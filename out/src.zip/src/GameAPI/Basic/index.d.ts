/* eslint-disable @typescript-eslint/triple-slash-reference */

/// <reference path="IntPos.d.ts" />
/// <reference path="FloatPos.d.ts" />
/// <reference path="DirectionAngle.d.ts" />
/// <reference path="mc.d.ts" />
